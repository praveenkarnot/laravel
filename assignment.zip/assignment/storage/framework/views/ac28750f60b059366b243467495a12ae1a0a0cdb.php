<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-lg-12 margin-tb">

            <div class="pull-left">

                <h2>Product Listing</h2>

            </div>


        </div>

    </div>



    <?php if($message = Session::get('success')): ?>

        <div class="alert alert-success">

            <p><?php echo e($message); ?></p>

        </div>

    <?php endif; ?>



    <table class="table table-bordered">

        <tr>



            <th>Name</th>



            <th width="280px">Action</th>

        </tr>

        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>



            <td><?php echo e($product->name); ?></td>



            <td>

                <form action="<?php echo e(route('addtocart',$product->uuid)); ?>" method="POST">
<?php echo csrf_field(); ?>
<input type='text' name='qty' id='qty' value=''/>
                    <button type="submit" class="btn">Add to cart</button>

                </form>

            </td>

        </tr>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </table>



    <?php echo $products->links(); ?>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/MAMP/htdocs/assignment/resources/views/home/index.blade.php ENDPATH**/ ?>