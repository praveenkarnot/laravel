<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Melihovv\ShoppingCart\Facades\ShoppingCart as Cart;

class CartController extends Controller {

  public function addToCart($uuid, Request $request) {

    $product = Product::where('uuid',$uuid)->first();
    $cartItem = Cart::add($product->id,$product->name,$product->price, 1);
    Cart::store(1);
    Cart::instance('cart')->store(1);

    return redirect()->route('home')->with('success', 'Added product successfully.');
  }
}
